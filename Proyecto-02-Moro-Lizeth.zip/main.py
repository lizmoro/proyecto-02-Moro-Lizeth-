import csv

lista_datos = []

with open("synergy_logistics_database.csv","r") as archivo_csv:
  lector = csv.reader(archivo_csv)

  for linea in lector: 
      lista_datos.append(linea)
      #print (linea)

def rutas (direccion):
    contador = 0 
    rutas_contadas = []
    conteo_rutas = []

    for ruta in lista_datos:
      if ruta[1] == direccion: 
          ruta_actual = [ruta[2], ruta[3]]

          if ruta_actual not in rutas_contadas:
            for movimiento in lista_datos:
                if ruta_actual == [movimiento[2], movimiento[3]]:
                    contador +=1
            
            rutas_contadas.append(ruta_actual)
            conteo_rutas.append([ruta[2], ruta[3],contador])
            contador =0
    conteo_rutas.sort(reverse=True, key =lambda x:x [2])
    
    return (conteo_rutas)


print ("*Bienvenido*")  
opc = int (input("Elige una opcion: \n 1.Importaciones más demandas \n 2.Exportaciones más demandadas \n opcion elegida:"))


if opc ==1:
    lista_rutas = rutas ("Imports")
elif opc ==2:
  lista_rutas = rutas ("Exports")  
else: 
  print ("opción incorrecta")

print(lista_rutas[0:9])  



    


